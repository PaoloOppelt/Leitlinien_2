# LeitlinienGPT
The LeitlinienGPT app builds a semantic search layer on the German medical guidelines.
This enables doctors to directly query the scientifically proven principles of the AWMF guidelines
